// redis-client.js — Подключение к Redis
const { createClient } = require('redis');

const client = createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379',
    socket: {
        reconnectStrategy: (retries) => {
            if (retries > 10) {
                console.error('❌ Redis: превышено число попыток подключения');
                return new Error('Too many retries');
            }
            return Math.min(retries * 100, 3000);
        }
    }
});

client.on('error', (err) => console.error('❌ Redis ошибка:', err.message));
client.on('connect', () => console.log('✅ Redis: подключен'));
client.on('reconnecting', () => console.log('🔄 Redis: переподключение...'));
client.on('ready', () => console.log('✅ Redis: готов к работе'));

(async () => {
    try {
        await client.connect();
    } catch (err) {
        console.error('❌ Redis: не удалось подключиться:', err.message);
        process.exit(1);
    }
})();

module.exports = client;
