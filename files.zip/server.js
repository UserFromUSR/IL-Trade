// server.js — Точка входа для IL-Trading Journal PRO+
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');
const routes = require('./routes');

const app = express();
const PORT = process.env.PORT || 3000;

// ═══════════════════════════════════════════════════════════
// МИДЛВАРЫ БЕЗОПАСНОСТИ И ОПТИМИЗАЦИИ
// ═══════════════════════════════════════════════════════════
app.use(helmet({
    contentSecurityPolicy: false, // Для работы Telegram WebApp скриптов
}));

app.use(cors({
    origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 минут
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests, please try again later.' }
});
app.use('/api', apiLimiter);

// ═══════════════════════════════════════════════════════════
// СТАТИЧЕСКИЕ ФАЙЛЫ
// ═══════════════════════════════════════════════════════════
app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0
}));

// ═══════════════════════════════════════════════════════════
// API МАРШРУТЫ
// ═══════════════════════════════════════════════════════════
app.use('/api', routes);

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', uptime: process.uptime(), timestamp: new Date().toISOString() });
});

// ═══════════════════════════════════════════════════════════
// SPA FALLBACK
// ═══════════════════════════════════════════════════════════
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ═══════════════════════════════════════════════════════════
// ГЛОБАЛЬНЫЙ ОБРАБОТЧИК ОШИБОК
// ═══════════════════════════════════════════════════════════
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err.stack);
    res.status(500).json({ error: 'Internal server error' });
});

// ═══════════════════════════════════════════════════════════
// ЗАПУСК
// ═══════════════════════════════════════════════════════════
app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен на порту ${PORT}`);
    console.log(`🔗 WebApp: http://localhost:${PORT}`);
    console.log(`🌍 Среда: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
