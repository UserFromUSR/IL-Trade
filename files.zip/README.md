# ⚡ IL-Trading Journal PRO+

Telegram Mini App для профессиональных крипто-трейдеров.
Торговый журнал с автокалькулятором позиции, статистикой, LIVE-трансляциями и автопостингом в Telegram-канал.

---

## 📁 Структура репозитория

```
il-trades-journal-pro/
├── .gitignore
├── .env.example          ← шаблон переменных окружения
├── package.json
├── server.js             ← точка входа Express
├── redis-client.js       ← подключение к Redis
├── routes.js             ← все API эндпоинты
├── README.md
└── public/
    └── index.html        ← Telegram Mini App (фронтенд)
```

---

## 🚀 Шаг 1 — Загрузка на GitHub

### 1.1 Установи Git (если не установлен)
- Скачай: https://git-scm.com/downloads
- Проверь: `git --version`

### 1.2 Создай репозиторий на GitHub
1. Зайди на https://github.com
2. Нажми **New repository**
3. Название: `il-trades-journal-pro`
4. Тип: **Private** (обязательно — здесь будут токены!)
5. Нажми **Create repository**

### 1.3 Подготовь папку с файлами локально

Создай папку и положи в неё **все файлы** из этого репозитория:
```
il-trades-journal-pro/
├── .gitignore
├── .env.example
├── package.json
├── server.js
├── redis-client.js
├── routes.js
└── public/
    └── index.html
```

> ⚠️ Файл `.env` (с реальными токенами) **не создавай в папке заранее** — он создаётся только на сервере.

### 1.4 Инициализируй и запушь

Открой терминал в папке проекта:

```bash
# Инициализация
git init
git add .
git commit -m "Initial commit: IL-Trading Journal PRO+"

# Подключение к GitHub (замени YOUR_USERNAME на свой логин)
git remote add origin https://github.com/YOUR_USERNAME/il-trades-journal-pro.git
git branch -M main
git push -u origin main
```

---

## 🔥 Шаг 2 — Firebase (Realtime Database)

Firebase используется как **дополнительное хранилище** для LIVE-функционала и резервного копирования данных.

### 2.1 Получи конфиг Firebase

1. Зайди в https://console.firebase.google.com
2. Выбери проект **il-trade**
3. Перейди в **Project Settings** (шестерёнка) → **General**
4. Прокрути вниз до **Your apps** → нажми **</> Web**
5. Скопируй объект `firebaseConfig` — он выглядит так:

```javascript
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "il-trade.firebaseapp.com",
  databaseURL: "https://il-trade-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "il-trade",
  storageBucket: "il-trade.appspot.com",
  messagingSenderId: "...",
  appId: "..."
};
```

### 2.2 Настрой правила Realtime Database

В Firebase Console → **Realtime Database** → **Rules** вставь:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "live": {
      ".read": true,
      ".write": "auth != null"
    }
  }
}
```

### 2.3 Добавь Firebase в `.env`

```env
FIREBASE_DATABASE_URL=https://il-trade-default-rtdb.europe-west1.firebasedatabase.app
FIREBASE_PROJECT_ID=il-trade
```

---

## 🖥️ Шаг 3 — Деплой на сервер

### Вариант A — Railway (рекомендуется, бесплатно)

1. Зайди на https://railway.app
2. **New Project** → **Deploy from GitHub repo**
3. Выбери `il-trades-journal-pro`
4. Railway автоматически определит Node.js
5. Перейди в **Variables** и добавь все переменные из `.env.example`:

```
PORT=3000
NODE_ENV=production
REDIS_URL=redis://...        ← Railway даёт Redis как сервис
TELEGRAM_BOT_TOKEN=...
ADMIN_IDS=...
FIREBASE_DATABASE_URL=https://il-trade-default-rtdb.europe-west1.firebasedatabase.app
```

6. Добавь Redis: **New** → **Add Service** → **Redis**
7. Скопируй `REDIS_URL` из Redis-сервиса в переменные
8. Railway автоматически задеплоит при каждом `git push`

### Вариант B — VPS (Render, DigitalOcean и т.д.)

```bash
# На сервере
git clone https://github.com/YOUR_USERNAME/il-trades-journal-pro.git
cd il-trades-journal-pro
npm install

# Создай .env файл
cp .env.example .env
nano .env  # вставь реальные значения

# Запуск через PM2
npm install -g pm2
pm2 start server.js --name "il-trading"
pm2 save
pm2 startup
```

---

## 🤖 Шаг 4 — Подключение к Telegram

### 4.1 Настрой BotFather
```
/setmenubutton — установи кнопку открытия Mini App
/setwebapp — укажи URL задеплоенного приложения
```

### 4.2 URL приложения
После деплоя Railway даст тебе URL вида:
```
https://il-trades-journal-pro.up.railway.app
```
Этот URL вставляй в BotFather как Web App URL.

### 4.3 Проверь работу
- Открой бота в Telegram
- Нажми кнопку меню → должен открыться Mini App
- Проверь `/health` эндпоинт: `https://твой-домен.app/health`

---

## 🔑 Переменные окружения

| Переменная | Описание | Пример |
|---|---|---|
| `PORT` | Порт сервера | `3000` |
| `NODE_ENV` | Среда | `production` |
| `REDIS_URL` | URL Redis | `redis://localhost:6379` |
| `TELEGRAM_BOT_TOKEN` | Токен бота от BotFather | `123456:ABC...` |
| `ADMIN_IDS` | ID администраторов | `123456789,987654321` |
| `FIREBASE_DATABASE_URL` | URL Firebase RTDB | `https://...firebasedatabase.app` |

---

## 📡 API Эндпоинты

| Метод | URL | Описание |
|---|---|---|
| `GET` | `/api/init?uid=` | Загрузка всех данных пользователя |
| `POST` | `/api/trade` | Создание сделки |
| `POST` | `/api/trade/:id/close` | Закрытие сделки |
| `PUT` | `/api/trade/:id` | Обновление сделки |
| `DELETE` | `/api/trade/:id` | Удаление сделки |
| `GET` | `/api/stats/:period` | Статистика (day/week/month/year) |
| `POST` | `/api/settings` | Сохранение настроек |
| `GET/POST` | `/api/channel` | Настройки Telegram-канала |
| `POST` | `/api/channel/post` | Пост в канал |
| `GET` | `/api/live/check` | Проверка доступа к LIVE |
| `POST` | `/api/live/request` | Заявка на LIVE |
| `POST` | `/api/live/approve` | Одобрение заявки (admin) |
| `POST` | `/api/live/block` | Блокировка пользователя (admin) |
| `GET` | `/health` | Статус сервера |

---

## 🛠️ Локальная разработка

```bash
# Установка зависимостей
npm install

# Запуск Redis (нужен Docker или локальная установка)
docker run -d -p 6379:6379 redis:alpine

# Создание .env
cp .env.example .env
# Заполни TELEGRAM_BOT_TOKEN и ADMIN_IDS

# Запуск в режиме разработки
npm run dev
```

Приложение будет доступно на http://localhost:3000

---

## ❓ Что скидывать дальше

Для продолжения работы над проектом скидывай:
- Новые файлы которые хочешь добавить
- Скриншоты с ошибками
- Описание нового функционала который нужно добавить

---

*IL-Trading Journal PRO+ © 2024*
