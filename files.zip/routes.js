// routes.js — IL-Trades Journal PRO+ API
// Серверная логика для Telegram Mini App

const express = require('express');
const router = express.Router();

// ═══════════════════════════════════════════════════════════
// ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ (Redis)
// ═══════════════════════════════════════════════════════════
const redis = require('./redis-client');

const db = {
  async get(key) {
    try {
      const data = await redis.get(key);
      return data ? JSON.parse(data) : null;
    } catch (err) {
      console.error(`DB GET error [${key}]:`, err.message);
      return null;
    }
  },
  async set(key, value) {
    try {
      await redis.set(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`DB SET error [${key}]:`, err.message);
      return false;
    }
  },
  async del(key) {
    try {
      await redis.del(key);
      return true;
    } catch (err) {
      console.error(`DB DEL error [${key}]:`, err.message);
      return false;
    }
  }
};

// ═══════════════════════════════════════════════════════════
// УТИЛИТЫ
// ═══════════════════════════════════════════════════════════
function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

function parseUid(uid) {
  if (!uid) return null;
  const parsed = parseInt(uid);
  return isNaN(parsed) ? uid : parsed.toString();
}

function calculatePnL(trade, closePrice, quantity) {
  const priceDiff = trade.side === 'LONG'
    ? closePrice - trade.entry
    : trade.entry - closePrice;
  const pnlPercent = (priceDiff / trade.entry) * 100 * trade.leverage;
  const pnl = (priceDiff * quantity) * trade.leverage;
  return { pnl, pnlPercent };
}

function validateTradeData(data) {
  const required = ['side', 'asset', 'entry'];
  for (const field of required) {
    if (!data[field]) {
      return { valid: false, error: `Missing required field: ${field}` };
    }
  }
  if (!['LONG', 'SHORT'].includes(data.side)) {
    return { valid: false, error: 'Invalid side. Must be LONG or SHORT' };
  }
  if (data.entry <= 0 || (data.stop && data.stop <= 0)) {
    return { valid: false, error: 'Prices must be positive' };
  }
  return { valid: true };
}

// ═══════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════

// ─────────────────────────────────────────────
// GET /init — Загрузка всех данных пользователя
// ─────────────────────────────────────────────
router.get('/init', async (req, res) => {
  try {
    const uid = parseUid(req.query.uid);
    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const [trades, settings, channel, user] = await Promise.all([
      db.get(`trades:${uid}`),
      db.get(`settings:${uid}`),
      db.get(`channel:${uid}`),
      db.get(`user:${uid}`)
    ]);

    const response = {
      trades: trades || [],
      settings: settings || { deposit: 1000, riskPercent: 1, leverage: 10, defaultAsset: '' },
      channel: channel || { enabled: false },
      user: user || { uid, createdAt: new Date().toISOString() }
    };

    const referrer = await db.get(`referrer:${uid}`);
    if (referrer) response.referrer = referrer;

    res.json(response);
  } catch (err) {
    console.error('Init error:', err);
    res.status(500).json({ error: 'Failed to load data' });
  }
});

// ─────────────────────────────────────────────
// POST /trade — Создание новой сделки
// ─────────────────────────────────────────────
router.post('/trade', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const tradeData = req.body;
    const validation = validateTradeData(tradeData);
    if (!validation.valid) return res.status(400).json({ error: validation.error });

    const trade = {
      id: generateId(),
      date: tradeData.date || new Date().toISOString().split('T')[0],
      time: tradeData.time || new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
      side: tradeData.side,
      asset: tradeData.asset,
      deposit: tradeData.deposit || 1000,
      leverage: tradeData.leverage || 10,
      riskPercent: tradeData.riskPercent || 1,
      entry: parseFloat(tradeData.entry),
      stop: tradeData.stop ? parseFloat(tradeData.stop) : null,
      tp1: tradeData.tp1 ? parseFloat(tradeData.tp1) : null,
      tp2: tradeData.tp2 ? parseFloat(tradeData.tp2) : null,
      tp3: tradeData.tp3 ? parseFloat(tradeData.tp3) : null,
      tp1Percent: tradeData.tp1Percent || 33,
      tp2Percent: tradeData.tp2Percent || 33,
      tp3Percent: tradeData.tp3Percent || 34,
      positionSize: tradeData.positionSize || 0,
      status: 'open',
      createdAt: new Date().toISOString()
    };

    if (trade.deposit && trade.riskPercent && trade.stop && trade.entry) {
      const riskAmount = trade.deposit * (trade.riskPercent / 100);
      const priceDiff = Math.abs(trade.entry - trade.stop);
      trade.positionSize = riskAmount / (priceDiff * trade.leverage);
      trade.positionSize = Math.round(trade.positionSize * 10000) / 10000;
    }

    const trades = (await db.get(`trades:${uid}`)) || [];
    trades.unshift(trade);
    await db.set(`trades:${uid}`, trades);

    const channel = await db.get(`channel:${uid}`);
    if (channel?.enabled && channel?.autoPostOpen) {
      sendToChannel(uid, formatTradeMessage(trade, 'open'));
    }

    res.status(201).json({ success: true, trade });
  } catch (err) {
    console.error('Create trade error:', err);
    res.status(500).json({ error: 'Failed to create trade' });
  }
});

// ─────────────────────────────────────────────
// POST /trade/:id/close — Закрытие сделки
// ─────────────────────────────────────────────
router.post('/trade/:id/close', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const tradeId = req.params.id;
    const action = req.body.action || 'full';
    const closePrice = parseFloat(req.body.closePrice);
    const partialPercent = parseFloat(req.body.partialPercent) || 50;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const trades = await db.get(`trades:${uid}`);
    if (!trades) return res.status(404).json({ error: 'Trades not found' });

    const tradeIndex = trades.findIndex(t => t.id === tradeId);
    if (tradeIndex === -1) return res.status(404).json({ error: 'Trade not found' });

    const trade = trades[tradeIndex];

    if (trade.status === 'closed') {
      return res.status(400).json({ error: 'Trade already closed' });
    }

    let closeReason = '';
    let finalClosePrice = closePrice;
    let closeQuantity = trade.positionSize;

    switch (action) {
      case 'partial':
        closeReason = `Partial ${partialPercent}%`;
        finalClosePrice = closePrice || trade.entry;
        const partialMultiplier = partialPercent / 100;
        closeQuantity = trade.positionSize * partialMultiplier;
        trade.positionSize = trade.positionSize * (1 - partialMultiplier);
        trade.partialClose = {
          percent: partialPercent,
          price: finalClosePrice,
          pnl: calculatePnL(trade, finalClosePrice, closeQuantity).pnl,
          timestamp: new Date().toISOString()
        };
        break;

      case 'tp1only':
        closeReason = 'TP1 reached';
        finalClosePrice = trade.tp1;
        closeQuantity = trade.positionSize * ((trade.tp1Percent || 33) / 100);
        trade.positionSize = trade.positionSize * (1 - (trade.tp1Percent || 33) / 100);
        trade.tp1Reached = true;
        break;

      case 'tp1tp2':
        closeReason = 'TP1+TP2 reached';
        finalClosePrice = trade.tp2;
        closeQuantity = trade.positionSize;
        trade.positionSize = 0;
        trade.tp1Reached = true;
        trade.tp2Reached = true;
        break;

      case 'be':
        closeReason = 'Breakeven';
        finalClosePrice = trade.entry;
        const bePercent = 50;
        closeQuantity = trade.positionSize * (bePercent / 100);
        trade.positionSize = trade.positionSize * (1 - bePercent / 100);
        trade.stop = trade.entry;
        trade.beTriggered = true;
        break;

      case 'tp1be':
        closeReason = 'TP1 + Breakeven';
        const tp1BeQuantity = trade.positionSize * ((trade.tp1Percent || 33) / 100);
        closeQuantity = tp1BeQuantity;
        trade.positionSize = trade.positionSize * (1 - (trade.tp1Percent || 33) / 100);
        trade.stop = trade.entry;
        trade.tp1Reached = true;
        trade.beTriggered = true;
        break;

      case 'early':
        closeReason = 'Early close';
        finalClosePrice = closePrice || trade.entry;
        trade.positionSize = 0;
        break;

      case 'stop':
        closeReason = 'Stop loss';
        finalClosePrice = trade.stop;
        trade.positionSize = 0;
        break;

      case 'customstop':
        closeReason = 'Custom stop';
        finalClosePrice = closePrice;
        trade.positionSize = 0;
        break;

      case 'full':
      default:
        closeReason = 'Manual close';
        finalClosePrice = closePrice || trade.entry;
        closeQuantity = trade.positionSize;
        trade.positionSize = 0;
        break;
    }

    const { pnl, pnlPercent } = calculatePnL(trade, finalClosePrice, closeQuantity);

    trade.status = trade.positionSize > 0 ? 'partial' : 'closed';
    trade.closeAction = action;
    trade.closeReason = closeReason;
    trade.closePrice = finalClosePrice;
    trade.closeTime = new Date().toISOString();
    trade.pnl = (trade.pnl || 0) + pnl;
    trade.pnlPercent = trade.positionSize > 0
      ? (pnlPercent * (partialPercent / 100))
      : pnlPercent;

    trades[tradeIndex] = trade;
    await db.set(`trades:${uid}`, trades);

    const channel = await db.get(`channel:${uid}`);
    if (channel?.enabled) {
      const postType = action === 'partial' ? 'partial' : 'close';
      if ((action === 'partial' && channel.autoPostPartial) ||
          (action !== 'partial' && channel.autoPostClose)) {
        sendToChannel(uid, formatTradeMessage(trade, postType));
      }
    }

    res.json({ success: true, trade });
  } catch (err) {
    console.error('Close trade error:', err);
    res.status(500).json({ error: 'Failed to close trade' });
  }
});

// ─────────────────────────────────────────────
// PUT /trade/:id — Обновление сделки
// ─────────────────────────────────────────────
router.put('/trade/:id', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const tradeId = req.params.id;
    const updateData = req.body;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const trades = await db.get(`trades:${uid}`);
    if (!trades) return res.status(404).json({ error: 'Trades not found' });

    const tradeIndex = trades.findIndex(t => t.id === tradeId);
    if (tradeIndex === -1) return res.status(404).json({ error: 'Trade not found' });

    const trade = trades[tradeIndex];

    const allowedFields = [
      'entry', 'stop', 'tp1', 'tp2', 'tp3',
      'tp1Percent', 'tp2Percent', 'tp3Percent',
      'positionSize', 'deposit', 'leverage', 'riskPercent',
      'notes', 'screenshot'
    ];

    for (const field of allowedFields) {
      if (updateData[field] !== undefined) {
        if (['entry', 'stop', 'tp1', 'tp2', 'tp3', 'positionSize', 'deposit'].includes(field)) {
          trade[field] = parseFloat(updateData[field]);
        } else {
          trade[field] = updateData[field];
        }
      }
    }

    if (updateData.deposit || updateData.riskPercent || updateData.stop || updateData.entry) {
      if (trade.deposit && trade.riskPercent && trade.stop && trade.entry) {
        const riskAmount = trade.deposit * (trade.riskPercent / 100);
        const priceDiff = Math.abs(trade.entry - trade.stop);
        trade.positionSize = riskAmount / (priceDiff * trade.leverage);
        trade.positionSize = Math.round(trade.positionSize * 10000) / 10000;
      }
    }

    trade.updatedAt = new Date().toISOString();
    trades[tradeIndex] = trade;
    await db.set(`trades:${uid}`, trades);

    res.json({ success: true, trade });
  } catch (err) {
    console.error('Update trade error:', err);
    res.status(500).json({ error: 'Failed to update trade' });
  }
});

// ─────────────────────────────────────────────
// DELETE /trade/:id — Удаление сделки
// ─────────────────────────────────────────────
router.delete('/trade/:id', async (req, res) => {
  try {
    const uid = parseUid(req.query.uid);
    const tradeId = req.params.id;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const trades = await db.get(`trades:${uid}`);
    if (!trades) return res.status(404).json({ error: 'Trades not found' });

    const filteredTrades = trades.filter(t => t.id !== tradeId);
    if (filteredTrades.length === trades.length) {
      return res.status(404).json({ error: 'Trade not found' });
    }

    await db.set(`trades:${uid}`, filteredTrades);
    res.json({ success: true, deleted: tradeId });
  } catch (err) {
    console.error('Delete trade error:', err);
    res.status(500).json({ error: 'Failed to delete trade' });
  }
});

// ─────────────────────────────────────────────
// GET /stats/:period — Статистика
// ─────────────────────────────────────────────
router.get('/stats/:period', async (req, res) => {
  try {
    const uid = parseUid(req.query.uid);
    const period = req.params.period;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const trades = (await db.get(`trades:${uid}`)) || [];

    const now = new Date();
    let startDate, endDate = now;

    switch (period) {
      case 'day':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        const dayOfWeek = now.getDay() || 7;
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek + 1);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), 0, 1);
    }

    const periodTrades = trades.filter(t => {
      const tradeDate = new Date(t.date);
      return tradeDate >= startDate && tradeDate <= endDate;
    });

    const closedTrades = periodTrades.filter(t => t.status === 'closed' || t.status === 'partial');

    let totalPnL = 0, totalWins = 0, totalLosses = 0;
    let bestTrade = { pnl: 0 }, worstTrade = { pnl: 0 };
    let wins = 0, losses = 0;
    let winStreak = 0, lossStreak = 0;
    let currentWinStreak = 0, currentLossStreak = 0;

    closedTrades.forEach(trade => {
      const pnl = trade.pnl || 0;
      totalPnL += pnl;

      if (pnl > 0) {
        wins++;
        totalWins += pnl;
        currentWinStreak++;
        currentLossStreak = 0;
        winStreak = Math.max(winStreak, currentWinStreak);
      } else if (pnl < 0) {
        losses++;
        totalLosses += Math.abs(pnl);
        currentLossStreak++;
        currentWinStreak = 0;
        lossStreak = Math.max(lossStreak, currentLossStreak);
      }

      if (pnl > bestTrade.pnl) bestTrade = trade;
      if (pnl < worstTrade.pnl) worstTrade = trade;
    });

    const totalTrades = wins + losses;
    const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;
    const avgWin = wins > 0 ? totalWins / wins : 0;
    const avgLoss = losses > 0 ? totalLosses / losses : 0;
    const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;

    const byDay = {};
    periodTrades.forEach(trade => {
      const day = trade.date;
      if (!byDay[day]) byDay[day] = { trades: [], pnl: 0, wins: 0, losses: 0 };
      byDay[day].trades.push(trade);
      if (trade.pnl > 0) byDay[day].wins++;
      if (trade.pnl < 0) byDay[day].losses++;
      byDay[day].pnl += trade.pnl || 0;
    });

    res.json({
      period,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      summary: {
        totalTrades,
        wins,
        losses,
        winRate: Math.round(winRate * 10) / 10,
        totalPnL: Math.round(totalPnL * 100) / 100,
        avgWin: Math.round(avgWin * 100) / 100,
        avgLoss: Math.round(avgLoss * 100) / 100,
        profitFactor: Math.round(profitFactor * 100) / 100,
        bestTrade: bestTrade.pnl ? { asset: bestTrade.asset, pnl: bestTrade.pnl, pnlPercent: bestTrade.pnlPercent } : null,
        worstTrade: worstTrade.pnl ? { asset: worstTrade.asset, pnl: worstTrade.pnl, pnlPercent: worstTrade.pnlPercent } : null,
        winStreak,
        lossStreak
      },
      byDay
    });
  } catch (err) {
    console.error('Stats error:', err);
    res.status(500).json({ error: 'Failed to calculate stats' });
  }
});

// ─────────────────────────────────────────────
// POST /settings — Сохранение настроек
// ─────────────────────────────────────────────
router.post('/settings', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const settings = req.body.settings;

    if (!uid) return res.status(400).json({ error: 'User ID required' });
    if (!settings) return res.status(400).json({ error: 'Settings object required' });

    const validatedSettings = {
      deposit: Math.max(0, parseFloat(settings.deposit) || 1000),
      riskPercent: Math.min(100, Math.max(0, parseFloat(settings.riskPercent) || 1)),
      leverage: Math.max(1, parseFloat(settings.leverage) || 10),
      defaultAsset: settings.defaultAsset || '',
      theme: settings.theme || 'dark',
      notifications: settings.notifications !== false,
      autoCalcPosition: settings.autoCalcPosition !== false
    };

    await db.set(`settings:${uid}`, validatedSettings);
    res.json({ success: true, settings: validatedSettings });
  } catch (err) {
    console.error('Save settings error:', err);
    res.status(500).json({ error: 'Failed to save settings' });
  }
});

// ─────────────────────────────────────────────
// CHANNEL — Telegram канал
// ─────────────────────────────────────────────
router.get('/channel', async (req, res) => {
  try {
    const uid = parseUid(req.query.uid);
    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const channel = await db.get(`channel:${uid}`);
    res.json(channel || { enabled: false });
  } catch (err) {
    console.error('Get channel error:', err);
    res.status(500).json({ error: 'Failed to get channel' });
  }
});

router.post('/channel', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const channelData = req.body;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const channel = {
      channelId: channelData.channelId || '',
      channelName: channelData.channelName || '',
      enabled: !!channelData.enabled,
      autoPostOpen: !!channelData.autoPostOpen,
      autoPostPartial: !!channelData.autoPostPartial,
      autoPostClose: !!channelData.autoPostClose,
      messageTemplate: channelData.messageTemplate || 'default',
      updatedAt: new Date().toISOString()
    };

    await db.set(`channel:${uid}`, channel);
    res.json({ success: true, channel });
  } catch (err) {
    console.error('Save channel error:', err);
    res.status(500).json({ error: 'Failed to save channel' });
  }
});

router.post('/channel/post', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const { message, photo, tradeId } = req.body;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const channel = await db.get(`channel:${uid}`);
    if (!channel?.enabled || !channel?.channelId) {
      return res.status(400).json({ error: 'Channel not configured' });
    }

    if (tradeId) {
      const cached = await db.get(`channelPosts:${uid}:${tradeId}`);
      if (cached) return res.json({ success: true, cached: true, messageId: cached.messageId });
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const sendUrl = photo
      ? `https://api.telegram.org/bot${botToken}/sendPhoto`
      : `https://api.telegram.org/bot${botToken}/sendMessage`;

    const body = photo
      ? { chat_id: channel.channelId, photo, caption: message, parse_mode: 'HTML' }
      : { chat_id: channel.channelId, text: message, parse_mode: 'HTML' };

    const tgRes = await fetch(sendUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const tgData = await tgRes.json();

    if (tradeId && tgData.result?.message_id) {
      await db.set(`channelPosts:${uid}:${tradeId}`, { messageId: tgData.result.message_id });
    }

    res.json({ success: true, messageId: tgData.result?.message_id });
  } catch (err) {
    console.error('Channel post error:', err);
    res.status(500).json({ error: 'Failed to post to channel' });
  }
});

// ─────────────────────────────────────────────
// LIVE — Трансляции
// ─────────────────────────────────────────────

// GET /live/admin — Список заявок и whitelist
router.get('/live/admin', async (req, res) => {
  try {
    const uid = parseUid(req.query.uid);
    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const isAdmin = process.env.ADMIN_IDS?.split(',').includes(uid);
    if (!isAdmin) return res.status(403).json({ error: 'Admin access required' });

    const [requests, whitelist] = await Promise.all([
      db.get('live:requests'),
      db.get('live:whitelist')
    ]);

    res.json({ requests: requests || [], whitelist: whitelist || [] });
  } catch (err) {
    console.error('Live admin error:', err);
    res.status(500).json({ error: 'Failed to load admin data' });
  }
});

// POST /live/request — Заявка на доступ
router.post('/live/request', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const { role, view, username, firstName } = req.body;

    const requests = (await db.get('live:requests')) || [];
    const existing = requests.find(r => r.uid === uid && r.status === 'pending');
    if (existing) return res.status(400).json({ error: 'Request already pending' });

    const request = {
      id: generateId(),
      uid,
      username: username || '',
      firstName: firstName || '',
      role: role || 'viewer',
      view: view || 'watch',
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    requests.push(request);
    await db.set('live:requests', requests);

    await notifyAdmins(
      `📬 <b>Новая заявка на LIVE</b>\n\n👤 ${firstName || username || uid}\n🎭 Роль: ${role}\n🆔 ID: ${uid}`
    );

    res.json({ success: true, request });
  } catch (err) {
    console.error('Live request error:', err);
    res.status(500).json({ error: 'Failed to submit request' });
  }
});

// POST /live/approve — Одобрение заявки
router.post('/live/approve', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const { requestId, targetUid, role, expiresInDays } = req.body;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const isAdmin = process.env.ADMIN_IDS?.split(',').includes(uid);
    if (!isAdmin) return res.status(403).json({ error: 'Admin access required' });

    const requests = (await db.get('live:requests')) || [];
    const requestIndex = requests.findIndex(r => r.id === requestId || r.uid === targetUid);
    if (requestIndex === -1) return res.status(404).json({ error: 'Request not found' });

    const request = requests[requestIndex];
    request.status = 'approved';
    request.approvedBy = uid;
    request.approvedAt = new Date().toISOString();

    const expiresAt = expiresInDays
      ? new Date(Date.now() + expiresInDays * 86400000).toISOString()
      : null;

    const whitelist = (await db.get('live:whitelist')) || [];
    whitelist.push({
      uid: request.uid,
      username: request.username,
      firstName: request.firstName,
      role: role || request.role,
      expiresAt,
      approvedBy: uid,
      approvedAt: new Date().toISOString()
    });

    requests[requestIndex] = request;
    await db.set('live:requests', requests);
    await db.set('live:whitelist', whitelist);

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const expiresText = expiresAt
      ? `\n⏰ Действителен до: ${new Date(expiresAt).toLocaleString('ru-RU')}`
      : '\n🔓 Бессрочный доступ';

    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: request.uid,
        text: `✅ <b>Доступ к LIVE одобрен!</b>\n\n🎭 Роль: ${request.role}${expiresText}\n\n🚀 Откройте приложение и начните трансляцию!`,
        parse_mode: 'HTML'
      })
    });

    res.json({ success: true, request, whitelistEntry: whitelist[whitelist.length - 1] });
  } catch (err) {
    console.error('Live approve error:', err);
    res.status(500).json({ error: 'Failed to approve request' });
  }
});

// POST /live/block — Блокировка доступа
router.post('/live/block', async (req, res) => {
  try {
    const uid = parseUid(req.body.uid);
    const { requestId, targetUid, reason } = req.body;

    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const isAdmin = process.env.ADMIN_IDS?.split(',').includes(uid);
    if (!isAdmin) return res.status(403).json({ error: 'Admin access required' });

    const targetId = targetUid || requestId;
    if (!targetId) return res.status(400).json({ error: 'Target ID required' });

    let whitelist = (await db.get('live:whitelist')) || [];
    whitelist = whitelist.filter(u => u.uid !== targetId);
    await db.set('live:whitelist', whitelist);

    if (requestId) {
      const requests = (await db.get('live:requests')) || [];
      const requestIndex = requests.findIndex(r => r.id === requestId);
      if (requestIndex !== -1) {
        requests[requestIndex].status = 'blocked';
        requests[requestIndex].blockedBy = uid;
        requests[requestIndex].blockedAt = new Date().toISOString();
        requests[requestIndex].blockReason = reason || '';
        await db.set('live:requests', requests);
      }
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: targetId,
        text: `❌ <b>Доступ к LIVE заблокирован</b>\n\n${reason ? 'Причина: ' + reason : 'Обратитесь к администратору.'}`,
        parse_mode: 'HTML'
      })
    });

    res.json({ success: true, blocked: targetId });
  } catch (err) {
    console.error('Live block error:', err);
    res.status(500).json({ error: 'Failed to block user' });
  }
});

// GET /live/check — Проверка доступа пользователя
router.get('/live/check', async (req, res) => {
  try {
    const uid = parseUid(req.query.uid);
    if (!uid) return res.status(400).json({ error: 'User ID required' });

    const whitelist = (await db.get('live:whitelist')) || [];
    const userAccess = whitelist.find(u => u.uid === uid);

    if (!userAccess) return res.json({ hasAccess: false });

    if (userAccess.expiresAt && new Date(userAccess.expiresAt) < new Date()) {
      return res.json({ hasAccess: false, reason: 'Access expired', expiredAt: userAccess.expiresAt });
    }

    res.json({ hasAccess: true, role: userAccess.role, expiresAt: userAccess.expiresAt });
  } catch (err) {
    console.error('Live check error:', err);
    res.status(500).json({ error: 'Failed to check access' });
  }
});

// ═══════════════════════════════════════════════════════════
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ═══════════════════════════════════════════════════════════

function formatTradeMessage(trade, type) {
  const side = trade.side === 'LONG' ? '🟢 LONG' : '🔴 SHORT';
  const pnlEmoji = (trade.pnl || 0) >= 0 ? '✅' : '❌';

  let message = `<b>${side}</b> ${trade.asset}\n`;
  message += `📍 Вход: <code>${trade.entry.toLocaleString()}</code>\n`;

  if (type === 'open') {
    message += `🛡️ Стоп: <code>${trade.stop?.toLocaleString() || '—'}</code>\n`;
    if (trade.tp1) message += `🎯 TP1: <code>${trade.tp1.toLocaleString()}</code>\n`;
    if (trade.tp2) message += `🎯 TP2: <code>${trade.tp2.toLocaleString()}</code>\n`;
    message += `📊 Плечо: <code>${trade.leverage}x</code>\n`;
    message += `💰 Размер: <code>${trade.positionSize}</code>`;
  } else if (type === 'partial') {
    message += `${pnlEmoji} Частичное закрытие: <code>${trade.partialClose?.percent}%</code>\n`;
    message += `📍 Закрыто по: <code>${trade.closePrice?.toLocaleString()}</code>\n`;
    message += `${pnlEmoji} P&L: <code>${trade.partialClose?.pnl?.toFixed(2)} USDT</code>`;
  } else {
    message += `📍 Закрыто по: <code>${trade.closePrice?.toLocaleString()}</code>\n`;
    message += `${pnlEmoji} P&L: <code>${trade.pnl?.toFixed(2)} USDT</code>\n`;
    message += `${pnlEmoji} %: <code>${trade.pnlPercent?.toFixed(2)}%</code>\n`;
    message += `📋 Причина: ${trade.closeReason || '—'}`;
  }

  return message;
}

async function sendToChannel(uid, message, photo) {
  try {
    const channel = await db.get(`channel:${uid}`);
    if (!channel?.enabled || !channel?.channelId) return;

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const sendUrl = photo
      ? `https://api.telegram.org/bot${botToken}/sendPhoto`
      : `https://api.telegram.org/bot${botToken}/sendMessage`;

    await fetch(sendUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(
        photo
          ? { chat_id: channel.channelId, photo, caption: message }
          : { chat_id: channel.channelId, text: message, parse_mode: 'HTML' }
      )
    });
  } catch (err) {
    console.error('Send to channel error:', err);
  }
}

async function notifyAdmins(message) {
  try {
    const adminIds = process.env.ADMIN_IDS?.split(',') || [];
    if (adminIds.length === 0) return;

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    for (const adminId of adminIds) {
      await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: adminId,
          text: message,
          parse_mode: 'HTML'
        })
      });
    }
  } catch (err) {
    console.error('Notify admins error:', err);
  }
}

// ═══════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════
module.exports = router;
